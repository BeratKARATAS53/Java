public interface PostInterface
{
	public static int maxVideoLength = 10;
	
	public static void setText(String a)
	{
	}
	
	public static void getText()
	{
	}
	
	public static void getID()
	{
	}
	
	public static void getDate()
	{	
	}
}
