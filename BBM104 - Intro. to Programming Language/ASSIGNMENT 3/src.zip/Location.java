public class Location
{
	public static double latitude;
	public static double longitude;
}
