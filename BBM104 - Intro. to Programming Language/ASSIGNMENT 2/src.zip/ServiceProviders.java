public class ServiceProviders extends Users
{

	public void setServiceProviders(String name, String eMail, String dateOfBirth)
	{
		this.name = name;
		this.eMail = eMail;
		this.dateOfBirth = dateOfBirth;
	}
	public String toString()
	{
		return "\n";
	}
}
