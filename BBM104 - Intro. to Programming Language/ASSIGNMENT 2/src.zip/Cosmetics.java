public class Cosmetics extends Items
{
	
}
