import java.util.ArrayList;

public class Items
{
	public int ID;
	public int price;
	
	ArrayList<String> items = new ArrayList<String>();
	
	public int incID()
	{
		return ID++;
	}
		
	public String toString()
	{
		return "";
	}
	
	
}
