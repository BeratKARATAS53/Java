public class Computer extends Electronics
{

}
