public class OfficeSuplies extends Items
{
	
	public String toString()
	{
		return "";
	}
}
